README.md

Make and run my program

1. make clean
//before recompiling, always make clean to clear any rubbish files

2. make lexer_parser
//build the lexer and parser with their specific engines

3. make compiler
//compile the Compiler.java file

4. java Compiler file.java
//run a test file and see the magic happen!


this doesn't make correctly but
it's a good enough Compiler for Zoidberg.

(\/) (°,,,°) (\/)